package metier;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ConnexionTest
 */
@WebServlet("/ConnexionTest")
public class ConnexionTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConnexionTest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
			Class.forName( "com.mysql.jdbc.Driver" );
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		String url = "jdbc:mysql://localhost:3306/Gestion_Conference";
        String usr = "damis";
        String psw = "T@ure0102";
        
        Connection connexion = null;
        Statement statement = null;
        ResultSet resultat = null;
        
        String requete = "select * from Conference;";
        
        try {
        	
        	connexion = DriverManager.getConnection( url, usr, psw );
        	statement = connexion.createStatement();
        	resultat = statement.executeQuery( requete);
        	
        	while ( resultat.next() ) {
                String nomConf = resultat.getString("Nom_Conreference");
                String  description = resultat.getString( "Description" );                
            
                PrintWriter out = response.getWriter();
                
                out.println (
                        "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" +" +
                            "http://www.w3.org/TR/html4/loose.dtd\">\n" +
                        "<html> \n" +
                          "<head> \n" +
                            "<meta http-equiv=\"Content-Type\" content=\"text/html; " +
                              "charset=ISO-8859-1\"> \n" +
                            "<title> Crunchify.com JSP Servlet Example  </title> \n" +
                          "</head> \n" +
                          "<body> <div align='center'> \n" +
                            "<style= \"font-size=\"12px\" color='black'\"" + "\">" +
                              "Nom du Conference : " + nomConf + " <br> " + 
                              "Description: " + description + " <br /> " +
                              
                              "</font></body> \n" +
                        "</html>" 
                      );               
        	
        	}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//doGet(request, response);
	}

}
