package metier;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InscriptionServlet
 */
@WebServlet("/InscriptionServlet")
public class InscriptionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InscriptionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id_conference = request.getParameter("id_conf");
        String title= request.getParameter("titld");
		String first_name = request.getParameter("f_name");
        String last_name= request.getParameter("l_name");
        String institution = request.getParameter("institution");
        String adress= request.getParameter("adress");
		String zip = request.getParameter("zip");
        String cuntry= request.getParameter("cuntry");
        String email= request.getParameter("email");
		String phone = request.getParameter("phone");
        String type_inscription= request.getParameter("t_inscription");
        
        PrintWriter out = response.getWriter();
        
        out.println (
                "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" +" +
                    "http://www.w3.org/TR/html4/loose.dtd\">\n" +
                "<html> \n" +
                  "<head> \n" +
                    "<meta http-equiv=\"Content-Type\" content=\"text/html; " +
                      "charset=ISO-8859-1\"> \n" +
                    "<title> Crunchify.com JSP Servlet Example  </title> \n" +
                  "</head> \n" +
                  "<body> <div align='center'> \n" +
                    "<style= \"font-size=\"12px\" color='black'\"" + "\">" +
                      "Num Conference : " + id_conference + " <br> " + 
                      "Title: " + title + " <br /> " +
                      "First name: " + first_name + " <br> " + 
                      "Last name: " + last_name + " <br /> " +
                      "Institution: " + institution + " <br> " + 
                      "Adress: " + adress + " <br /> " +
                      "Zip: " + zip + " <br> " + 
                      "Cuntry: " + cuntry + " <br /> " +
                      "E-mail: " + email + " <br> " + 
                      "Phone: " + phone + " <br /> " +
                      "Type Inscription: " + type_inscription + " <br /> " +
                  "</font></body> \n" +
                "</html>" 
              );
		//doGet(request, response);
	}

}
