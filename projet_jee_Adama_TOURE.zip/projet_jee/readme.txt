# Application de gestion d’inscriptions à une conférence
***
 Un projet de développement d'une application des gestions des inscriptions à une
conférence, en utilisant les technologies JEE (jsp,servlets)

Pour l'execution de projet,
importer les les deux projets eclipse : GestionConference er Servers(pour tomcat) 